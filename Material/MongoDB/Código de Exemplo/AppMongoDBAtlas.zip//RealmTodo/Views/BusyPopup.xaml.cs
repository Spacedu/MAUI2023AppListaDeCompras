﻿using CommunityToolkit.Maui.Views;

namespace RealmTodo.Views;

public partial class BusyPopup : Popup
{
    public BusyPopup()
    {
        InitializeComponent();
    }
}
