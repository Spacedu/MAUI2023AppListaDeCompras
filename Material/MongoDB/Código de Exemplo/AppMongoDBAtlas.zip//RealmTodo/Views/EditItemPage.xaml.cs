﻿namespace RealmTodo.Views;

public partial class EditItemPage : ContentPage
{
    public EditItemPage()
    {
        InitializeComponent();
    }
}
