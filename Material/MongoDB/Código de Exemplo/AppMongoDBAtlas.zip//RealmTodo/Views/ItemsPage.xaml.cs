﻿namespace RealmTodo.Views;

public partial class ItemsPage : ContentPage
{
	public ItemsPage()
	{
		InitializeComponent();
	}
}
